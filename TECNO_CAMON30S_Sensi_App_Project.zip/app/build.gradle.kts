plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.sradszone.camon30ssensi"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.sradszone.camon30ssensi"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
